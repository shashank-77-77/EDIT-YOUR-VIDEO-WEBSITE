import { User } from "../models/userModel.js";
import TryCatch from "../utils/Trycatch.js";
import generateToken from "../utils/generateToken.js";
import getDataUrl from "../utils/urlGenrator.js";
import bcrypt from "bcrypt";
import cloudinary from "cloudinary";

// ===============================
// Register User
// ===============================
export const registerUser = TryCatch(async (req, res) => {
  const { name, email, password, gender } = req.body;
  const file = req.file;

  if (!name || !email || !password || !gender || !file) {
    return res.status(400).json({ message: "Please give all values" });
  }

  let user = await User.findOne({ email });
  if (user) {
    return res.status(400).json({ message: "User Already Exist" });
  }

  const fileUrl = getDataUrl(file);
  const hashPassword = await bcrypt.hash(password, 10);
  const myCloud = await cloudinary.v2.uploader.upload(fileUrl.content);

  user = await User.create({
    name,
    email,
    password: hashPassword,
    gender,
    // role defaults to "User" (schema-level)
    profilePic: {
      id: myCloud.public_id,
      url: myCloud.secure_url,
    },
  });

  // 🔐 issue JWT (cookie + returnable token)
  const token = generateToken(user, res);

  res.status(201).json({
    message: "User Registered",
    _id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    token, // ✅ additive, safe
  });
});

// ===============================
// Login User
// ===============================
export const loginUser = TryCatch(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });
  if (!user) {
    return res.status(400).json({ message: "Invalid Credentials" });
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(400).json({ message: "Invalid Credentials" });
  }

  // 🔐 issue JWT (cookie + returnable token)
  const token = generateToken(user, res);

  res.json({
    _id: user._id,
    name: user.name,
    email: user.email,
    role: user.role, // 🔑 REQUIRED (Admin/User)
    token,           // 🔑 REQUIRED (cross-service auth)
  });
});

// ===============================
// Logout User
// ===============================
export const logoutUser = TryCatch((req, res) => {
  res.cookie("token", "", {
    httpOnly: true,
    expires: new Date(0),
  });

  res.json({
    message: "Logged out successfully",
  });
});
