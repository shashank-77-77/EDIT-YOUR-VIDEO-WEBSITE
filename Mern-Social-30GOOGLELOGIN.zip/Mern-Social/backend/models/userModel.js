import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
    },

    password: {
      type: String,
      required: true,
    },

    // 🆕 AUTH PROVIDER (BACKWARD-COMPATIBLE)
    provider: {
      type: String,
      enum: ["local", "google"],
      default: "local",
    },

    gender: {
      type: String,
      required: true,
      enum: ["male", "female"],
    },

    // 🔑 ROLE-BASED AUTH (BACKWARD-COMPATIBLE)
    role: {
      type: String,
      enum: ["User", "Admin"],
      default: "User",
    },

    followers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],

    followings: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],

    profilePic: {
      id: String,
      url: String,
    },
  },
  {
    timestamps: true,
  }
);

export const User = mongoose.model("User", userSchema);
