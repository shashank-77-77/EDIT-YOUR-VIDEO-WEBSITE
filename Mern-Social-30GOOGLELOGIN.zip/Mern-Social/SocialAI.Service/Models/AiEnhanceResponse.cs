namespace SocialAI.Service.Models;

public class AiEnhanceResponse
{
    public string EnhancedContent { get; set; } = string.Empty;
    public bool Success { get; set; }
}
