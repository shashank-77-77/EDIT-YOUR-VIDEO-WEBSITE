namespace SocialAI.Service.Models;

public class AiChatResponse
{
    public string Reply { get; set; } = string.Empty;
}
