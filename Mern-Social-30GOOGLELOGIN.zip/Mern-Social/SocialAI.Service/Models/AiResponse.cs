namespace SocialAI.Service.Models;

public class AiResponse
{
    public string Text { get; set; } = string.Empty;
}
