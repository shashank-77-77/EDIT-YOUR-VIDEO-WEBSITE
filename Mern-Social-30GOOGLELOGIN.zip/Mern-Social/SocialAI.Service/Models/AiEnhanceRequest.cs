namespace SocialAI.Service.Models;

public class AiEnhanceRequest
{
    public string Content { get; set; } = string.Empty;
}
