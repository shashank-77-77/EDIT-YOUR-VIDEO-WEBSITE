namespace SocialAI.Service.Models;

public class AiChatRequest
{
    public string Message { get; set; } = string.Empty;
}
