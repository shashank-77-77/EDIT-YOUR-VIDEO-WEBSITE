namespace SocialAI.Service.Models;

public class AiRequest
{
    public string Prompt { get; set; } = string.Empty;
}
