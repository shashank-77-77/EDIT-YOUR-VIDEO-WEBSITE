import { useEffect, useState } from "react";
import adminApi from "../../utils/adminApi";

const PAGE_SIZE = 10;

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);

  async function loadUsers(reset = false) {
    setLoading(true);
    const activePage = reset ? 1 : page;

    try {
      const { data } = await adminApi.get("/users", {
        params: {
          search,
          page: activePage,
          pageSize: PAGE_SIZE,
        },
      });

      setUsers(data.items);
      setTotalPages(data.totalPages);

      if (reset) setPage(1);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadUsers();
  }, [page]);

  // ===============================
  // ADMIN ACTIONS
  // ===============================
  const toggleBlock = async (id, isBlocked) => {
    await adminApi.put(`/users/${id}/block`);
    loadUsers();
  };

  const deleteUser = async (id) => {
    if (!confirm("Delete this user permanently?")) return;
    await adminApi.delete(`/users/${id}`);
    loadUsers();
  };

  const changeRole = async (id, role) => {
    await adminApi.put(`/users/${id}/role`, null, {
      params: { role },
    });
    loadUsers();
  };

  return (
    <div className="p-8 text-white bg-slate-900 min-h-screen">
      <h1 className="text-3xl font-bold mb-6">Admin Control Panel</h1>

      {/* Controls */}
      <div className="flex gap-3 mb-6">
        <input
          className="px-4 py-2 bg-slate-700 rounded"
          placeholder="Search by name or email"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <button
          onClick={() => loadUsers(true)}
          className="bg-blue-600 px-4 py-2 rounded"
        >
          Search
        </button>

        <button
          onClick={() => {
            setSearch("");
            loadUsers(true);
          }}
          className="bg-emerald-600 px-4 py-2 rounded"
        >
          Show All
        </button>
      </div>

      {/* Table */}
      <table className="w-full border border-slate-700">
        <thead className="bg-slate-800">
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {loading && (
            <tr>
              <td colSpan="6" className="text-center p-6">
                Loading…
              </td>
            </tr>
          )}

          {!loading &&
            users.map((u) => (
              <tr key={u.id} className="border-t border-slate-700">
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>
                  <select
                    value={u.role || "User"}
                    onChange={(e) =>
                      changeRole(u.id, e.target.value)
                    }
                    className="bg-slate-800"
                  >
                    <option value="User">User</option>
                    <option value="Admin">Admin</option>
                  </select>
                </td>
                <td>{u.isBlocked ? "Blocked" : "Active"}</td>
                <td>
                  {new Date(u.createdAt).toLocaleDateString()}
                </td>
                <td className="flex gap-2">
                  <button
                    onClick={() => toggleBlock(u.id, u.isBlocked)}
                    className="bg-yellow-600 px-2 rounded"
                  >
                    {u.isBlocked ? "Unblock" : "Block"}
                  </button>
                  <button
                    onClick={() => deleteUser(u.id)}
                    className="bg-red-600 px-2 rounded"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>

      {/* Pagination */}
      <div className="flex gap-4 mt-6">
        <button
          disabled={page === 1}
          onClick={() => setPage((p) => p - 1)}
        >
          Previous
        </button>
        <span>
          Page {page} of {totalPages}
        </span>
        <button
          disabled={page === totalPages}
          onClick={() => setPage((p) => p + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
}
