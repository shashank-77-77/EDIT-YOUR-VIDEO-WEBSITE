import { Navigate } from "react-router-dom";
import { UserData } from "../context/UserContext";

const AdminRoute = ({ children }) => {
  const { isAuth, user, loading } = UserData();

  if (loading) return null;

  // Not logged in → go to login
  if (!isAuth) {
    return <Navigate to="/login" replace />;
  }

  // Logged in but not admin → go home
  if (user?.role !== "Admin") {
    return <Navigate to="/" replace />;
  }

  // Admin → allow access
  return children;
};

export default AdminRoute;
