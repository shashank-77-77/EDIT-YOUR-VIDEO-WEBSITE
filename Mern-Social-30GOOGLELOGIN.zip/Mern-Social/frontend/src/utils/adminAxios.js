import axios from "axios";

const adminAxios = axios.create({
  baseURL: "http://localhost:5183/admin",
  withCredentials: true, // required for auth cookie
});

export default adminAxios;
