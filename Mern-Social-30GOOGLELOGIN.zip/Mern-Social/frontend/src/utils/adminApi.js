// import axios from "axios";

// const API = axios.create({
//   baseURL: "http://localhost:5183/admin",
//   withCredentials: true,
// });

// export const fetchUsers = async ({ search, page, pageSize }) => {
//   const res = await api.get("/users", {
//     params: {
//       search: search || "",
//       page,
//       pageSize
//     }
//   });
//   return res.data;
// };

// export const blockUser = (id) =>
//   API.put(`/users/${id}/block`);

// export const deleteUser = (id) =>
//   API.delete(`/users/${id}`);

//------------------------------------------------------

import axios from "axios";

const adminApi = axios.create({
  baseURL: "http://localhost:5183/admin",
  withCredentials: true,
});

export default adminApi;
