import React from "react";
import { Link, useLocation } from "react-router-dom";
import { UserData } from "../context/UserContext";

import { AiOutlineHome, AiFillHome } from "react-icons/ai";
import { BsCameraReelsFill, BsCameraReels } from "react-icons/bs";
import { IoSearchCircleOutline, IoSearchCircle } from "react-icons/io5";
import {
  IoChatbubbleEllipses,
  IoChatbubbleEllipsesOutline,
} from "react-icons/io5";
import { RiAccountCircleFill, RiAccountCircleLine } from "react-icons/ri";
import { MdAdminPanelSettings } from "react-icons/md";

const NavigationBar = () => {
  const location = useLocation();
  const activePath = location.pathname;
  const { user } = UserData();

  return (
    <div className="fixed bottom-0 left-0 w-full bg-white border-t border-gray-200 z-50">
      <div className="flex justify-around items-center py-3">

        <NavItem
          to="/"
          active={activePath === "/"}
          iconActive={<AiFillHome />}
          iconInactive={<AiOutlineHome />}
        />

        <NavItem
          to="/reels"
          active={activePath === "/reels"}
          iconActive={<BsCameraReelsFill />}
          iconInactive={<BsCameraReels />}
        />

        <NavItem
          to="/search"
          active={activePath === "/search"}
          iconActive={<IoSearchCircle />}
          iconInactive={<IoSearchCircleOutline />}
        />

        <NavItem
          to="/chat"
          active={activePath === "/chat"}
          iconActive={<IoChatbubbleEllipses />}
          iconInactive={<IoChatbubbleEllipsesOutline />}
        />

        {/* 🔐 ADMIN — HARD LINK (BYPASS REACT) */}
        {user?.role === "Admin" && (
          <a
            href="http://localhost:5183/admin"
            target="_blank"
            rel="noopener noreferrer"
            className="text-2xl text-gray-500 hover:text-black"
            title="Admin Control Panel"
          >
            <MdAdminPanelSettings />
          </a>
        )}

        <NavItem
          to="/account"
          active={activePath === "/account"}
          iconActive={<RiAccountCircleFill />}
          iconInactive={<RiAccountCircleLine />}
        />
      </div>
    </div>
  );
};

export default NavigationBar;

const NavItem = ({ to, active, iconActive, iconInactive }) => {
  return (
    <Link
      to={to}
      className={`text-2xl ${active ? "text-black" : "text-gray-500"}`}
    >
      {active ? iconActive : iconInactive}
    </Link>
  );
};
