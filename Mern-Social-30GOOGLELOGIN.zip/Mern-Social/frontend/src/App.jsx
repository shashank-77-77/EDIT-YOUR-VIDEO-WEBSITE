import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Account from "./pages/Account";
import Reels from "./pages/Reels";
import Search from "./pages/Search";
import ChatPage from "./pages/ChatPage";
import UserAccount from "./pages/UserAccount";

import NavigationBar from "./components/NavigationBar";
import NotFound from "./components/NotFound";
import { Loading } from "./components/Loading";

import { UserData } from "./context/UserContext";

// Admin
import UserManagement from "./pages/admin/UserManagement";
import AdminRoute from "./routes/AdminRoute";

const App = () => {
  const { loading, isAuth, user } = UserData();

  if (loading) return <Loading />;

  return (
    <BrowserRouter>
      <Routes>
        {/* ================= PUBLIC ================= */}
        <Route path="/login" element={!isAuth ? <Login /> : <Home />} />
        <Route path="/register" element={!isAuth ? <Register /> : <Home />} />

        {/* ================= AUTH ================= */}
        <Route path="/" element={isAuth ? <Home /> : <Login />} />
        <Route path="/reels" element={isAuth ? <Reels /> : <Login />} />
        <Route path="/search" element={isAuth ? <Search /> : <Login />} />
        <Route
          path="/chat"
          element={isAuth ? <ChatPage user={user} /> : <Login />}
        />
        <Route
          path="/account"
          element={isAuth ? <Account user={user} /> : <Login />}
        />
        <Route
          path="/user/:id"
          element={isAuth ? <UserAccount user={user} /> : <Login />}
        />

        {/* ================= ADMIN ================= */}
        <Route element={<AdminRoute />}>
          <Route path="/admin/users" element={<UserManagement />} />
        </Route>

        {/* ================= FALLBACK ================= */}
        <Route path="*" element={<NotFound />} />
      </Routes>

      {isAuth && <NavigationBar />}
    </BrowserRouter>
  );
};

export default App;
